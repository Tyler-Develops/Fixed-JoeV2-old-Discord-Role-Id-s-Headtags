# Headtags

## JoeV2s Developer Community 
[[Developer Discord]](https://discord.gg/sNHg4X7xt2)

### Version 1.0.3
- yes there will be further updates
  
#### Commands:
/tag-toggle - Turns off the prefix from being shown for the player (if they have a prefix in their tag)

/tags-toggle - Turns off all tags from being shown above other players for ONLY yourself (good for streamers and/or pictures)


#### Installation
1. Download Headtags 
2. Extract the .zip and place the folder in your /resources/ of your Fivem server
3. Start the resource in your server.cfg file
4. Enjoy :)


<img src="https://cdn.discordapp.com/attachments/1146625389037363371/1223189582049181799/image.png?ex=6618f312&is=66067e12&hm=fe82701af3c2c229b1e8217e200f44e3dd31b6c81879d890e891a08db5318ce0&" >
